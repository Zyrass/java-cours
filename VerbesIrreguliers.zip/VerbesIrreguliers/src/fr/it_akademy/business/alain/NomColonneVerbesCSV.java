package fr.it_akademy.business.alain;

public enum NomColonneVerbesCSV {
	NUMERO_LIGNE,
	BASE_VERBALE,
	PARTICIPE_PASSE,
	PRETERIT,
	TRADUCTION_FR
}
