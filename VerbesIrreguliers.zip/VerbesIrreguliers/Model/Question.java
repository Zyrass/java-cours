
import java.util.*;

/**
 * 
 */
public class Question {

    /**
     * Default constructor
     */
    public Question() {
    }

    /**
     * 
     */
    private Long id;

    /**
     * 
     */
    private String responsePreterit;

    /**
     * 
     */
    private String reponseParticipePasse;

    /**
     * 
     */
    private LocalDateTime dateHeureEnvoi;

    /**
     * 
     */
    private LocalDateTime dateHeureReponse;

    /**
     * 
     */
    private Long compteur;



    /**
     * 
     */
    private Partie partie;

    /**
     * 
     */
    private Verbe verbe;

    /**
     * @return
     */
    public Long getId() {
        // TODO implement here
        return null;
    }

    /**
     * @param value
     */
    public void setId(Long value) {
        // TODO implement here
    }

    /**
     * @return
     */
    public String getResponsePreterit() {
        // TODO implement here
        return "";
    }

    /**
     * @param value
     */
    public void setResponsePreterit(String value) {
        // TODO implement here
    }

    /**
     * @return
     */
    public String getReponseParticipePasse() {
        // TODO implement here
        return "";
    }

    /**
     * @param value
     */
    public void setReponseParticipePasse(String value) {
        // TODO implement here
    }

    /**
     * @return
     */
    public LocalDateTime getDateHeureEnvoi() {
        // TODO implement here
        return null;
    }

    /**
     * @param value
     */
    public void setDateHeureEnvoi(LocalDateTime value) {
        // TODO implement here
    }

    /**
     * @return
     */
    public LocalDateTime getDateHeureReponse() {
        // TODO implement here
        return null;
    }

    /**
     * @param value
     */
    public void setDateHeureReponse(LocalDateTime value) {
        // TODO implement here
    }

    /**
     * @return
     */
    public Long getCompteur() {
        // TODO implement here
        return null;
    }

    /**
     * @param value
     */
    public void setCompteur(Long value) {
        // TODO implement here
    }

}