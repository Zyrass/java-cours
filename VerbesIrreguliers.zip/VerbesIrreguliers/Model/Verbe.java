
import java.util.*;

/**
 * 
 */
public class Verbe {

    /**
     * Default constructor
     */
    public Verbe() {
    }

    /**
     * 
     */
    private Long id;

    /**
     * 
     */
    private String baseVerbale;

    /**
     * 
     */
    private String preterit;

    /**
     * 
     */
    private String participePasse;

    /**
     * 
     */
    private String traduction;

    /**
     * 
     */
    private Long compteur;

    /**
     * @return
     */
    public Long getId() {
        // TODO implement here
        return null;
    }

    /**
     * @param value
     */
    public void setId(Long value) {
        // TODO implement here
    }

    /**
     * @return
     */
    public String getBaseVerbale() {
        // TODO implement here
        return "";
    }

    /**
     * @param value
     */
    public void setBaseVerbale(String value) {
        // TODO implement here
    }

    /**
     * @return
     */
    public String getPreterit() {
        // TODO implement here
        return "";
    }

    /**
     * @param value
     */
    public void setPreterit(String value) {
        // TODO implement here
    }

    /**
     * @return
     */
    public String getParticipePasse() {
        // TODO implement here
        return "";
    }

    /**
     * @param value
     */
    public void setParticipePasse(String value) {
        // TODO implement here
    }

    /**
     * @return
     */
    public String getTraduction() {
        // TODO implement here
        return "";
    }

    /**
     * @param value
     */
    public void setTraduction(String value) {
        // TODO implement here
    }

    /**
     * @return
     */
    public Long getCompteur() {
        // TODO implement here
        return null;
    }

    /**
     * @param value
     */
    public void setCompteur(Long value) {
        // TODO implement here
    }

}