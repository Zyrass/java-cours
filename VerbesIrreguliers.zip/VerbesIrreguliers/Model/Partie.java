
import java.util.*;

/**
 * 
 */
public class Partie {

    /**
     * Default constructor
     */
    public Partie() {
    }

    /**
     * 
     */
    private Long id;

    /**
     * 
     */
    private int nbQuestionsSouhaitees;

    /**
     * 
     */
    private int score;

    /**
     * 
     */
    private Long compeur;



    /**
     * 
     */
    public Set<Question> questions;

    /**
     * @return
     */
    public Long getId() {
        // TODO implement here
        return null;
    }

    /**
     * @param value
     */
    public void setId(Long value) {
        // TODO implement here
    }

    /**
     * @return
     */
    public int getNbQuestionsSouhaitees() {
        // TODO implement here
        return 0;
    }

    /**
     * @param value
     */
    public void setNbQuestionsSouhaitees(int value) {
        // TODO implement here
    }

    /**
     * @return
     */
    public int getScore() {
        // TODO implement here
        return 0;
    }

    /**
     * @param value
     */
    public void setScore(int value) {
        // TODO implement here
    }

    /**
     * @return
     */
    public Long getCompeur() {
        // TODO implement here
        return null;
    }

    /**
     * @param value
     */
    public void setCompeur(Long value) {
        // TODO implement here
    }

}